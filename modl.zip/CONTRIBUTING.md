# Contributing to openui5-basic-template-app

In general the contributing guidelines of OpenUI5 also apply to this project. They can be found here:  
https://github.com/SAP/openui5/blob/master/CONTRIBUTING.md